function Shot(x,y)
{
  this.x=x;
  this.y=y;
  this.r=10;
  this.toDelete=false;
  
  this.show= function()
  {
    fill(150,0,255);
    noStroke();
    rect(this.x,this.y,this.r,20);
  
  
  }
  
  this.move=function()
  {
    
    this.y=this.y-10;
  
  
  }
  
  this.hits= function(invader)
  {
    var d=dist(this.x,this.y,invader.x,invader.y);
    
    if(d< this.r+invader.r)
    {
      console.log("WAS HIT");
      return true;
    }
    else
    {
      return false;
    
    }
  
  }
  
  this.disappear=function ()
  {
    this.toDelete=true;
  
  }


}
//source: https://github.com/CodingGarden/p5-brick-breaker/blob/master/Brick.js

//https://p5js.org/examples/objects-objects.html

//https://www.youtube.com/watch?v=rO6M5hj0V-o

