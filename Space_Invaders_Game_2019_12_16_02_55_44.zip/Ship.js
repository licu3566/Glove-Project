class Ball {
  constructor(location,r) 
  {
    
   
    this.location=location;
    //x location of this object
   
    //y location of this object
    this.r=r
    //radius of this circle
    
  }
  
  

  
  display()
  {
  
    //image by Mr BOZO on Noun Project
    //img=loadImage('Spaceship.png');
    image(img,this.location.x,this.location.y,this.r*2,this.r*2);
    
  
  
  }
  

  
  
}
