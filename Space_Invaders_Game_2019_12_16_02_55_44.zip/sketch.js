/*
This P5 sketch is a template for getting started with Serial Communication. 
The SerialEvent callback is where incoming data is received 


By Arielle Hein, adapted from ITP Phys Comp Serial Labs
Edited March 12 2019

*/

var inData;
var clear;
var i=0;
var track=0;
let circles=[];
let Invaders=[];
let balls=[];
let shots=[];
var accelerometer;
var flexSensor;
var track=0;
var score=0;
var created=false;

var serial; //variable to hold an instance of the serial port library
var portName = '/dev/tty.usbmodem1411'; //fill in with YOUR port
let img;
let img2;

function preload ()
{
  img=loadImage('Spaceship.png');
  img2=loadImage('Invader.png');
  
}

function setup() {
  createCanvas(500, 500);
  
  //https://www.youtube.com/watch?v=DEHsr4XicN8
//creates the canvas once and then does not repeatedly draw over it 

  serial = new p5.SerialPort(); //a new instance of serial port library


  //takes (width, height, posX,posY,sect)
 
  serial.write();
//  for(var k=0;k<6;k++)
//   {
//     Invaders[k]= new Invader(k*(width/24*3),20,width/24);
//     Invaders[k].show();
  
//   }
  //set up events for serial communication
  serial.on('connected', serverConnected);
  serial.on('open', portOpen);
  serial.on('data', serialEvent);
  serial.on('error', serialError);
  serial.on('close', portClose);

  //open our serial port
  serial.open(portName); 
  for(var k=0;k<7;k++)
  { 
    
    Invaders[k]= new Invader(k*(width/24*3),20,width/24);
    Invaders[k].show();
  
  }
  
  
  
  //let's figure out what port we're on - useful for determining your port
  // serial.on('list', printList); //set a callback function for the serialport list event
  // serial.list(); //list the serial ports
}

function draw() {
  
  var x=accelerometer;
  background(0,0,0);
  
  
  for(var j=0;j<shots.length;j++)
  {
    shots[j].show();
    shots[j].move();
    
    
       for(var h=0;h<Invaders.length;h++)
    {
      if(shots[j].hits(Invaders[h])==true)
      {
        Invaders.splice(h,1);
        shots[j].disappear();
        score++
        
      }
      
    }
  
  
  }
  
  for(j=shots.length-1;j>=0;j--)
  {
  
    if(shots[j].disappear())
    {
      shots.splice(j,1);

    }
  }
  
  var edge=false;
  
  for(var g=0;g<Invaders.length;g++)
  { 

    Invaders[g].show();
    Invaders[g].move();
    
    if(Invaders[g].x>width-Invaders[g].r||Invaders[g].x<0)
    {
      edge=true;
      Invaders[g].shiftDown();
      
     
    }
    
    if(Invaders[g].y > width+Invaders[g].r*2)
    {
      // background(0,0,255);
      console.log('YOU DIED');
    
    
    }
   

  }
  
  
  
    
  

 
  
  for(var u=0;u<circles.length;u++)
  {
    circles[u].show()

  
  }
  
  
    
  createBall(x,width-width/12);
  
  
}


//all my callback functions are down here:
//these are useful for giving feedback
function createBall(x,y)
{
  
  let ball=new Ball(createVector(x,y), width/24, color(255,255,255));
  balls[0]=ball;
  balls[0].display();
  



}

function serverConnected(){
  console.log('connected to the server');
}

function portOpen(){
  console.log('the serial port opened!');
}







//THIS IS WHERE WE RECEIVE DATA!!!!!!
//make sure you're reading data based on how you're sending from arduino
function serialEvent(){
  //credit: arielle Hein Code
  
  
  inData = serial.readLine(); //read until a carriage return

  //best practice is to make sure you're not reading null data
  if(inData.length > 0)
  {
    
    //delays it so that the data coming in is not as continous, making
    //it less shaky
    //source:Kevin Workman
    //https://stackoverflow.com/questions/45463382/capture-photos-from-video-after-specific-time-in-p5-js
    
    //split the values apart at the comma
    var numbers = split(inData, ',');
    flexSensor = Number(numbers[0]);
      
    
      if(flexSensor<110)
      {
        //Source:
        //https://www.youtube.com/watch?v=biN3v3ef-Y0
        //Coding Train
        if(frameCount % 13 == 0)
        {
          var shot=new Shot(balls[0].location.x,balls[0].location.y);
          shots[track]=shot;
          track++;

          
        }
        
       
        
      }
     if(frameCount % 10 == 0)
     {
    //set variables as numbers
   
    //console.log(potentiometer);
      
      
    accelerometer = Number(numbers[1]);
    
    //console.log(potentiometer2);
    accelerometer=map(accelerometer,-960,990,0,width-width/12);
    //since I know that the parameters of my circle are these dimensions, I can set it so that the edge of the circle can only touch the edges. Alternatively, I could pass the object or create a global variable.
    }
  }

  
}



function createBall(x,y)
{
  
  let ball=new Ball(createVector(x,y), width/24);
  balls[0]=ball;
  balls[0].display();
  



}

function serialError(err){
  console.log('something went wrong with the port. ' + err);
}

function portClose(){
  console.log('the port was closed');
}

function clearCanvas(){
  background('dodgerblue');
  
}
// get the list of ports:
function printList(portList) {
 // portList is an array of serial port names
 for (var i = 0; i < portList.length; i++) {
 // Display the list the console:
 print(i + " " + portList[i]);
 }


  
//source: https://github.com/CodingGarden/p5-brick-breaker/blob/master/Brick.js



  
}





function circle(x,y,r)
{
  this.x=x;
  this.y=y;
  this.r=r;
  
  this.show= function()
  {
    fill(100,0,200);
    noStroke();
    ellipse(this.x,this.y,this.r*2,this.r*2);
  
  
  }



}



