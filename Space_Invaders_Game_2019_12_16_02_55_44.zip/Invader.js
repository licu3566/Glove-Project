function Invader(x,y,r)
{
//Space Invader by Melvin Salas from the Noun Project 
  
  this.x=x;
  this.y=y;
  this.r=r;
  this.passing=false;
  
  this.xdir=2;
  
  this.show=function()
  {
     image(img2,this.x,this.y,this.r*2,this.r*2);
  
  }
  
  this.shiftDown=function()
  {
    this.xdir*=-1;
    this.y+=this.r+25;
  
  }
  
  this.move=function()
  {
    this.x=this.x+this.xdir;
  
  
  }
  
  this.past=function()
  {
    if(this.y>300)
    {
      return true;
    
    }
    this.passing=true;
  
  
  }
  
  
  
  
}
